Joblib tidak tersedia saat build. Di VPS, jalankan Optuna untuk membangun model XGB per-mode,
atau unggah file models/xgb_<mode>.joblib.