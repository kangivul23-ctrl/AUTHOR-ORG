#!/usr/bin/env bash
set -euo pipefail
python run.py --mode live --confirm
