# Intra-Module Auto-Fix Report

- Problems before: 1
- Auto-fixes applied: 0
- Problems after: 1

## Remaining issues
- core/alert_manager.py:5 → from .notifier import send_telegram_message (target: core.notifier.send_telegram_message)
